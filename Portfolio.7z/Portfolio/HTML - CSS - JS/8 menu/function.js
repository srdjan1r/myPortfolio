let hamMenu = document.querySelector(".container");

hamMenu.addEventListener("click", () => {
    hamMenu.classList.toggle("active");
});